cmd_/build/linux-U8fiFq/linux-4.15.0/debian/linux-headers-4.15.0-128-generic/usr/src/linux-headers-4.15.0-128-generic/tools/objtool/subcmd-config.o := gcc -Wp,-MD,/build/linux-U8fiFq/linux-4.15.0/debian/linux-headers-4.15.0-128-generic/usr/src/linux-headers-4.15.0-128-generic/tools/objtool/.subcmd-config.o.d -Wp,-MT,/build/linux-U8fiFq/linux-4.15.0/debian/linux-headers-4.15.0-128-generic/usr/src/linux-headers-4.15.0-128-generic/tools/objtool/subcmd-config.o -Wbad-function-cast -Wdeclaration-after-statement -Wformat-security -Wformat-y2k -Winit-self -Wmissing-declarations -Wmissing-prototypes -Wnested-externs -Wno-system-headers -Wold-style-definition -Wpacked -Wredundant-decls -Wshadow -Wstrict-prototypes -Wswitch-default -Wswitch-enum -Wundef -Wwrite-strings -Wformat -Wstrict-aliasing=3 -ggdb3 -Wall -Wextra -std=gnu99 -fPIC -O6 -Werror -D_LARGEFILE64_SOURCE -D_FILE_OFFSET_BITS=64 -D_GNU_SOURCE -I/build/linux-U8fiFq/linux-4.15.0/tools/include/ -D"BUILD_STR(s)=$(pound)s" -c -o /build/linux-U8fiFq/linux-4.15.0/debian/linux-headers-4.15.0-128-generic/usr/src/linux-headers-4.15.0-128-generic/tools/objtool/subcmd-config.o subcmd-config.c

source_/build/linux-U8fiFq/linux-4.15.0/debian/linux-headers-4.15.0-128-generic/usr/src/linux-headers-4.15.0-128-generic/tools/objtool/subcmd-config.o := subcmd-config.c

deps_/build/linux-U8fiFq/linux-4.15.0/debian/linux-headers-4.15.0-128-generic/usr/src/linux-headers-4.15.0-128-generic/tools/objtool/subcmd-config.o := \
  /usr/include/stdc-predef.h \
  subcmd-config.h \

/build/linux-U8fiFq/linux-4.15.0/debian/linux-headers-4.15.0-128-generic/usr/src/linux-headers-4.15.0-128-generic/tools/objtool/subcmd-config.o: $(deps_/build/linux-U8fiFq/linux-4.15.0/debian/linux-headers-4.15.0-128-generic/usr/src/linux-headers-4.15.0-128-generic/tools/objtool/subcmd-config.o)

$(deps_/build/linux-U8fiFq/linux-4.15.0/debian/linux-headers-4.15.0-128-generic/usr/src/linux-headers-4.15.0-128-generic/tools/objtool/subcmd-config.o):
